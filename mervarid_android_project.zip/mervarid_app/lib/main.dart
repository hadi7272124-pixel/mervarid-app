import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

void main() => runApp(const MervaridApp());

class MervaridApp extends StatelessWidget {
  const MervaridApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'پتروشیمی مروارید',
      theme: ThemeData(useMaterial3: true, fontFamily: 'sans-serif', colorSchemeSeed: Colors.indigo),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('راهنمای فرایند پتروشیمی مروارید'), centerTitle: true),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          _card(context, Icons.picture_as_pdf, 'مشاهده کامل PDF', 'تمام ۱۰۵ صفحه، شامل نقشه‌های PFD', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PdfPage()))),
          _card(context, Icons.map, 'نقشه‌های PFD', 'صفحات ۷۵ تا ۱۰۵', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PdfPage(startPage: 75)))),
          _card(context, Icons.search, 'جستجو', 'جستجو در متن و تگ تجهیزات', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SearchPage()))),
          _card(context, Icons.menu_book, 'دیکشنری تجهیزات', 'انگلیسی به فارسی', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DictionaryPage()))),
          _card(context, Icons.list_alt, 'فهرست بخش‌ها', 'پرش سریع به بخش‌های اصلی', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SectionsPage()))),
        ]),
      ),
    );
  }
  Widget _card(BuildContext c, IconData icon, String title, String sub, VoidCallback tap) => Card(
    child: ListTile(contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8), leading: Icon(icon, size: 32), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(sub), trailing: const Icon(Icons.chevron_left), onTap: tap),
  );
}

class PdfPage extends StatefulWidget {
  final int startPage;
  const PdfPage({super.key, this.startPage = 1});
  @override State<PdfPage> createState() => _PdfPageState();
}
class _PdfPageState extends State<PdfPage> {
  final controller = PdfViewerController();
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.startPage >= 75 ? 'نقشه‌های PFD' : 'سند فرایند'), actions: [
      IconButton(icon: const Icon(Icons.zoom_out), onPressed: () => controller.zoomLevel = ((controller.zoomLevel - .25).clamp(1.0, 8.0) as num).toDouble()),
      IconButton(icon: const Icon(Icons.zoom_in), onPressed: () => controller.zoomLevel = ((controller.zoomLevel + .25).clamp(1.0, 8.0) as num).toDouble()),
    ]),
    body: SfPdfViewer.asset('assets/pdf/mervarid.pdf', controller: controller, initialPageNumber: widget.startPage, initialZoomLevel: 1.0, enableDoubleTapZooming: true),
  );
}

class SearchPage extends StatefulWidget { const SearchPage({super.key}); @override State<SearchPage> createState()=>_SearchPageState(); }
class _SearchPageState extends State<SearchPage> {
  final q=TextEditingController(); List<Map<String,dynamic>> pages=[]; List<Map<String,dynamic>> results=[];
  @override void initState(){super.initState(); _load();}
  Future<void> _load() async { final s=await rootBundle.loadString('assets/data/search_index.json'); pages=List<Map<String,dynamic>>.from(jsonDecode(s)); }
  void _search(String v){ final x=v.trim().toLowerCase(); setState(()=>results=x.isEmpty?[]:pages.where((p)=>(p['text'] as String).toLowerCase().contains(x)).take(50).toList()); }
  @override Widget build(BuildContext context)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(appBar:AppBar(title:const Text('جستجو')),body:Column(children:[Padding(padding:const EdgeInsets.all(12),child:TextField(controller:q,onChanged:_search,decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'مثلاً C-301 یا کوره یا اتیلن',border:OutlineInputBorder()))),Expanded(child:ListView.builder(itemCount:results.length,itemBuilder:(c,i){final p=results[i]; final text=(p['text'] as String).replaceAll('\n',' '); return ListTile(title:Text('صفحه ${p['page']}'),subtitle:Text(text,maxLines:2,overflow:TextOverflow.ellipsis),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>PdfPage(startPage:p['page'] as int)));}))])));
}

class DictionaryPage extends StatefulWidget { const DictionaryPage({super.key}); @override State<DictionaryPage> createState()=>_DictionaryPageState(); }
class _DictionaryPageState extends State<DictionaryPage>{List<Map<String,dynamic>> data=[]; String q=''; @override void initState(){super.initState();rootBundle.loadString('assets/data/dictionary.json').then((s)=>setState(()=>data=List<Map<String,dynamic>>.from(jsonDecode(s))));} @override Widget build(BuildContext c){final r=data.where((x)=>('${x['en']} ${x['fa']}').toLowerCase().contains(q.toLowerCase())).toList();return Directionality(textDirection:TextDirection.rtl,child:Scaffold(appBar:AppBar(title:const Text('دیکشنری تجهیزات')),body:Column(children:[Padding(padding:const EdgeInsets.all(12),child:TextField(onChanged:(v)=>setState(()=>q=v),decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'جستجوی اصطلاح',border:OutlineInputBorder()))),Expanded(child:ListView.builder(itemCount:r.length,itemBuilder:(_,i)=>ListTile(title:Text(r[i]['en'] as String,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text(r[i]['fa'] as String),leading:const Icon(Icons.precision_manufacturing))))])));}}

class SectionsPage extends StatelessWidget { const SectionsPage({super.key});
  final sections=const [
    ['معرفی واحد اتیلن','5'],['تقسیم‌بندی نواحی','10'],['خوراک واحد','11'],['آشنایی با کوره‌های پیرولیز','13'],['فرآیند کوره‌های الفین','25'],['ناحیه تفکیک گرم','32'],['ناحیه ۳۰؛ کمپرسور اصلی','39'],['واحد غنی‌سازی اتیلن','45'],['سیستم تبرید پروپان و اتیلن','50'],['واحدهای کمکی و جانبی','60'],['ناحیه مخازن محصولات','69'],['نقشه‌های PFD','75']];
  @override Widget build(BuildContext c)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(appBar:AppBar(title:const Text('فهرست بخش‌ها')),body:ListView.builder(itemCount:sections.length,itemBuilder:(_,i)=>ListTile(title:Text(sections[i][0]),trailing:Text(sections[i][1]),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>PdfPage(startPage:int.parse(sections[i][1]))))))));
}
